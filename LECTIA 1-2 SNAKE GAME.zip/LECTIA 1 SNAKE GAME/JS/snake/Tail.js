class Tail {
    constructor(x=0, y=0, i=0){
        this.x = [x, x-2, x+2, x]
        this.y = [y+2, y, y, y-2]
        this.i = i
        ///          up  rg  lf  dn
        this.dirX =[192, 256, 192, 256] 
        this.dirY = [128, 128, 192, 192]  
         }
    render(){
return `
<div
style=" 
width: 64px;
height: 64px;
background: url(images/snake-graphics.png);
background-position: -${this.dirX[i]}px -${this.dirY[i]}px;
position: absolute;
 top: ${this.y[i]*64}px;
 left: ${this.x[i]*64}px;
"
></div>
`
    }
}