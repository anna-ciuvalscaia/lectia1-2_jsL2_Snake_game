// [Snake] > parent > [Head]

class Snake {
    // when creating a new snake -> attach a head to it
    constructor(x=0, y=0, i=0){
        this.x = x;
        this.y = y;
       // this.i = prompt("enter snake")
     this.head = new Head(x,y,i);
     this.body = new Body(x,y,i);  
     this.tail = new Tail(x,y,i);
      
    }
    
    // when rendering the SNAKE - also render
    render(){
       return this.head.render() +
       this.body.render() +
       this.tail.render()
      
    }
   
}

let i = prompt(`Introduceti directia Sarpelui:
"Up"- 0       "Right"- 1       "Left"- 2       "Down"-3
`)