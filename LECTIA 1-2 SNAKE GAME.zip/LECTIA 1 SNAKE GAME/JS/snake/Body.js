class Body {
    constructor(x=0, y=0, i=0){
        this.x = [x, x-1, x+1, x]
        this.y = [y+1, y, y, y-1]
        this.i = i
        ///          up  rg  lf  dn
        this.dirX = [128, 64, 64, 128]
        this.dirY = [64, 0, 0, 64]
      
         }
    render(){
return `
<div 
style="
width: 64px;
height: 64px;
background: url(images/snake-graphics.png);
background-position: -${this.dirX[i]}px -${this.dirY[i]}px;
position: absolute;
 top: ${this.y[i]*64}px;
 left: ${this.x[i]*64}px;
"
></div>
`
    }
}

