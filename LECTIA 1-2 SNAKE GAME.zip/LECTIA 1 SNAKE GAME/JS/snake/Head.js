
class Head {
   
    constructor(x=0, y=0, i=0){
       this.x = x
       this.y = y 
       this.i = i
       ///          up  rg  lf  dn
       this.dirX =[192, 256, 192, 256 ] 
       this.dirY = [0, 0, 64, 64]   
        }

    render(){
        return`
<div id="head" 
style="
width: 64px;
height: 64px;
background: url(images/snake-graphics.png);
background-position: -${this.dirX[i]}px -${this.dirY[i]}px;
position: absolute;
 top: ${this.y*64}px;
 left: ${this.x*64}px;
"
></div>`
    }
}



