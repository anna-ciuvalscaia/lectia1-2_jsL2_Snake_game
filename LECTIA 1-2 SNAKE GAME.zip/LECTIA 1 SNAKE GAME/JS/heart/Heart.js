class Heart {

    constructor(x=0, y=0){
        // 1=1 map square
       this.x = parseInt(1 + Math.random() * 9);
       this.y = parseInt(1 + Math.random() * 9);
        }
        // root
        // coordoinates
    render(){
        return  `
        <div 
        style="
        width: 64px;
        height: 64px;
        background: url(images/Heart.png);
        position: absolute;
        top: ${this.y*64}px;
        left: ${this.x*64}px;
        "
        ></div>
        `
            }
}